package com.capita.service;

import java.util.List;
import java.util.Map;

public interface EvaluateExpression {
	public Map<Integer,String> processExpression(List<String> expr);
}
