package com.capita.service.calculation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author vijay
 * This class will calculate the value of validated single expression.
 */
public class CalculateExpressionValueService {

	
	List<String> digitList = new ArrayList<String>();
	List<String> operatorList;
	List<String> literalList;
	CalculationStack calculationStack;
	
	
	public CalculateExpressionValueService(List<String> digitList, List<String> operatorList, List<String> literalList){
		this.digitList = digitList;
		this.operatorList = operatorList;
		calculationStack = new CalculationStack(operatorList, literalList);
	}
	
	Map<Integer, String> mapPriority = new HashMap<Integer, String>();
	
	/**
	 * 
	 * @param listExpr : Single expression in list format
	 * @return : value of the expression.
	 * @throws NumberFormatException
	 */
	public double calcuateExprValue(List<String> listExpr) throws NumberFormatException{
		double result = 1.0;
		boolean isLastChar = false;
		int c = 0;
		for(String literal : listExpr) {
			c++;
			if(c == listExpr.size()) {
				isLastChar = true;
			}
			List<String> exprToEval = calculationStack.push(literal,isLastChar);
			if(null != exprToEval && exprToEval.size() > 0 && !exprToEval.get(exprToEval.size()-1).equals("==")) {
				double value = calculateBraceExpr(exprToEval.subList(1, exprToEval.size()-1));
				exprToEval = calculationStack.push(value+"",isLastChar);
				if(c == listExpr.size()) {
					result = calculateBraceExpr(exprToEval.subList(0, exprToEval.size()-1));
				}
			}else if(null != exprToEval && exprToEval.size() > 0 && exprToEval.get(exprToEval.size()-1).equals("==")) {
				result = calculateBraceExpr(exprToEval.subList(0, exprToEval.size()-1));
			}
		}
		return result;
	}
	
	
	
	/**
	 * 
	 * @param listBraceExpr : Takes data between opening and closing braces as input. 
	 * @return : Value of this expression
	 */
	public double calculateBraceExpr(List<String> listBraceExpr) {
		StringBuffer sb = new StringBuffer("");
		
		for(String lit : listBraceExpr) {
			sb = sb.append(lit);
		}
		
		String equation = sb.toString();
		
		double result = 0.0;
		String noMinus = equation.replace("-", "+-");
		String[] byPluses = noMinus.split("\\+");

		for (String multipl : byPluses) {
			String[] byMultipl = multipl.split("\\*");
			double multiplResult = 1.0;
			double divident = 1.0;
			
			for (String operand : byMultipl) {
				if (operand.contains("/")) {
					String[] division = operand.split("\\/");
					
					int c = 0;
					for(String power : division) {
						
						double powerRes = 1.0;
						if(power.contains("^")) {
							String[] powerArr = power.split("\\^");
							double powerResult = Double.parseDouble(powerArr[0]);
							for (int i = 1; i < powerArr.length; i++) {
								powerResult = power(powerResult,Double.parseDouble(powerArr[i]));
							}
							powerRes = powerResult;
						}
						else {
							powerRes = Double.parseDouble(power);
						}
						if(c == 0) {
							divident = powerRes;
						}else {
							divident =  divident/powerRes;
						}
						c++;
					}
					multiplResult *= divident;
				} else {
					if(operand.contains("^")) {
						String[] powerArr = operand.split("\\^");
						double powerResult = Double.parseDouble(powerArr[0]);
						for (int i = 1; i < powerArr.length; i++) {
							powerResult = power(powerResult,Double.parseDouble(powerArr[i]));
						}
						multiplResult *= powerResult;
					}else {
						divident = Double.parseDouble(operand);
						multiplResult *= divident;
					}
				}
			}
			result += multiplResult;
		}

		return result;
		
	}
	
	public static double power(double x, double y) {
		return Math.pow(x, y);
	}
	
}
