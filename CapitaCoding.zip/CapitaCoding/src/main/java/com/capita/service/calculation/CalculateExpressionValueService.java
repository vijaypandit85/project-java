package com.capita.service.calculation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author vijay
 * This class will calculate the value of validated single expression.
 */
public class CalculateExpressionValueService {

	
	List<String> digitList = new ArrayList<String>();
	List<String> operatorList;
	List<String> literalList;
	CalculationStack calculationStack;
	
	
	public CalculateExpressionValueService(List<String> digitList, List<String> operatorList, List<String> literalList){
		this.digitList = digitList;
		this.operatorList = operatorList;
		calculationStack = new CalculationStack(operatorList, literalList);
	}
	
	Map<Integer, String> mapPriority = new HashMap<Integer, String>();
	
	/**
	 * 
	 * @param listExpr : Single expression in list format
	 * @return : value of the expression.
	 * @throws NumberFormatException
	 */
	public int calcuateExprValue(List<String> listExpr) throws NumberFormatException{
		int result = -1;
		int c = 0;
		setPriority();
		for(String literal : listExpr) {
			c++;
			List<String> exprToEval = calculationStack.push(literal);
			if(null != exprToEval && exprToEval.size() > 0 && !exprToEval.get(exprToEval.size()-1).equals("==")) {
				int value = calculateBraceExpr(exprToEval.subList(1, exprToEval.size()-1));
				exprToEval = calculationStack.push(value+"");
				if(c == listExpr.size()) {
					result = calculateBraceExpr(exprToEval.subList(0, exprToEval.size()-1));
				}
			}else if(null != exprToEval && exprToEval.size() > 0 && exprToEval.get(exprToEval.size()-1).equals("==")) {
				result = calculateBraceExpr(exprToEval.subList(0, exprToEval.size()-1));
			}
		}
		return result;
	}
	
	
	/**
	 * 
	 * @param listBraceExpr : Takes data between opening and closing braces as input. 
	 * @return : Value of this expression
	 */
	public int calculateBraceExpr(List<String> listBraceExpr) {
		StringBuffer sb = new StringBuffer("");
		
		for(String lit : listBraceExpr) {
			sb = sb.append(lit);
		}
		
		evaluatePow(sb);
		evaluateDiv(sb);
		evaluateMul(sb);
		evaluateSum(sb);
		evaluateSub(sb);
		
		return Integer.parseInt(sb.toString());
	}
	
	/**
	 *  This is used to evaluate the power expression.
	 *  If expression have more then one power it calculates it.  
	 */
	public StringBuffer evaluatePow(StringBuffer sb) {
		int powRes = -1;
		for (int i = 0; i < sb.length(); i++) {
			if(sb.charAt(i) == '^') {
				int x = getBeforeChar(sb,i-1);
				int y = getAfterChar(sb, i+1);
				powRes = calculatePow(x,y);
				sb.replace(i- (x+"").length(), i+(y+"").length()+1, powRes+"");
				i--;
			}
		}
		return sb;
	}
	
	
	/**
	 *  This is used to evaluate the division expression.
	 *  If expression have more then one division it calculates it.  
	 */
	public StringBuffer evaluateDiv(StringBuffer sb) {
		int devRes = -1;
		for (int i = 0; i < sb.length(); i++) {
			if(sb.charAt(i) == '/') {
				int x = getBeforeChar(sb,i-1);
				int y = getAfterChar(sb, i+1);
				devRes = calculateDiv(x,y);
				sb.replace(i- (x+"").length(), i+(y+"").length()+1, devRes+"");
				i--;
			}
		}
		return sb;
	}
	
	/**
	 *  This is used to evaluate the multiple expression.
	 *  If expression have more then one multiple it calculates it.  
	 */
	public  StringBuffer evaluateMul(StringBuffer sb) {
		int mulRes = -1;
		for (int i = 0; i < sb.length(); i++) {
			if(sb.charAt(i) == '*') {
				int x = getBeforeChar(sb,i-1);
				int y = getAfterChar(sb, i+1);
				mulRes = calculateMul(x,y);
				sb.replace(i- (x+"").length(), i+(y+"").length()+1, mulRes+"");
				i--;
			}
		}
		return sb;
	}
	
	
	/**
	 *  This is used to evaluate the sum expression.
	 *  If expression have more then one sum it calculates it.  
	 */
	public  StringBuffer evaluateSum(StringBuffer sb) {
		int sumRes = -1;
		for (int i = 0; i < sb.length(); i++) {
			if(sb.charAt(i) == '+') {
				int x = getBeforeChar(sb,i-1);
				int y = getAfterChar(sb, i+1);
				sumRes = calculateSum(x,y);
				sb.replace(i- (x+"").length(), i+(y+"").length()+1, sumRes+"");
				i--;
			}
		}
		return sb;
	}
	
	/**
	 *  This is used to evaluate the subtract expression.
	 *  If expression have more then one subtract it calculates it.  
	 */
	public  StringBuffer evaluateSub(StringBuffer sb) {
		int subRes = -1;
		for (int i = 0; i < sb.length(); i++) {
			if(sb.charAt(i) == '-') {
				int x = getBeforeChar(sb,i-1);
				int y = getAfterChar(sb, i+1);
				subRes = calculateSub(x,y);
				sb.replace(i- (x+"").length(), i+(y+"").length()+1, subRes+"");
				i--;
			}
		}
		return sb;
	}
	
	
	public  int calculatePow(int x, int y) {
		return (int)Math.pow(x, y);
	}
	public  int calculateDiv(int x, int y) {
		return (int)x/y;
	}
	public  int calculateMul(int x, int y) {
		return x*y;
	}
	public  int calculateSum(int x, int y) {
		return x+y;
	}
	public  int calculateSub(int x, int y) {
		return x-y;
	}
	
	/**
	 * It calculates the character before pos position till it gets and operator. 
	 */
	public  int getBeforeChar(StringBuffer sb, int pos) {
		StringBuffer ch = new StringBuffer("");
		while(pos >= 0) {
			if(digitList.contains(sb.charAt(pos)+"")) {
				ch = ch.append(sb.charAt(pos));
			}else {
				break;
			}
			pos --;
		}
		return Integer.parseInt(ch.reverse().toString());
	}
	
	
	/**
	 * It calculates the character after pos position till it gets and operator. 
	 */
	public  int getAfterChar(StringBuffer sb, int pos) {
		StringBuffer ch = new StringBuffer("");
		while(pos < sb.length()) {
			if(digitList.contains(sb.charAt(pos)+"")) {
				ch = ch.append(sb.charAt(pos));
			}else {
				break;
			}
			pos ++;
		}
		return Integer.parseInt(ch.toString());
	}
	
	
	/**
	 * 
	 * @return Priority mapping of operators
	 * 
	 */
	public Map<Integer,String> setPriority(){
		mapPriority.put(1, "^");
		mapPriority.put(2, "/");
		mapPriority.put(3, "*");
		mapPriority.put(4, "+");
		mapPriority.put(5, "-");
		return mapPriority;
	}
}
