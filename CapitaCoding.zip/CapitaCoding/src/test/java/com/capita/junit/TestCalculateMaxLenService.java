package com.capita.junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capita.serviceImpl.EvaluateExpressionImpl;

/**
 * 
 * @author vijay
 * Test cases for CalculateMaxLenService class
 */
public class TestCalculateMaxLenService {
	EvaluateExpressionImpl evalExpr = new EvaluateExpressionImpl();
	
	   @Test
	   public void testMaxLengthOne() {
		   assertEquals(evalExpr.processSingleExpression("7+(6*5^2+3-4/2)"),"158");
	   }
	   
	   
	   @Test
	   public void testMaxLengthTwo() {
		   assertEquals(evalExpr.processSingleExpression("7+(67(56*2))"),"INVALID EXPRESSION");
	   }
}
